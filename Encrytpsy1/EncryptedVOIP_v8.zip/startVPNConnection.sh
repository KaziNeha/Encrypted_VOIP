cd /home/user/Documents
su -c 'openvpn --config vpnbook-us1-udp53.ovpn  --auth-user-pass VpnBookPwd.txt'
