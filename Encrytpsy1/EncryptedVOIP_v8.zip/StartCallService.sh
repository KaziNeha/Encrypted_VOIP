cd /home/user/Documents/EncrytedVOIP
python GUI.py
